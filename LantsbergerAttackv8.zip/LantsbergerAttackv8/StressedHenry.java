import javafx.scene.image.Image;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
/**
 * Constructor for objects of class MrL holds information about the player Mr Lanstburger,
 * like the image and the weapon it's using
 *
 * @author (JaneWang)
 * @version (05212018)
 */
public class StressedHenry extends Player
{
    private static Weapon puck = new Weapon(4, 0, 0, 40, 40, new Image("puck.png"));
    private static Weapon w2 = new Weapon(6, 0, 0, 40, 40, new Image("puck.png"));
    private static Weapon w3 = new Weapon(9, 0, 0, 40, 40, new Image("puck.png"));
    
    // how far into animation (milliseconds)
    private int loopTime;
    
    /**
     * Constructor for objects of class MrL holds information about the player Mr Lanstburger,
     * like the image and the weapon it's using
     */
    public StressedHenry(double x, double y)
    {
        super(x, y, 30, 70, new Image("henry.png"), 1, puck, puck, puck);
    }
    /**
     * method draw - shows Mr L animated and with an awesome health bar
     * @param   gc  what to draw on
     * @param   millis  time since the last draw
     */
    @Override
    public void draw(GraphicsContext gc, int millis)
    {
        // which image to get
        int pos = 0;
        int[] order = {1, 2, 1, 5};
        
        // updates time of loop
        loopTime += millis;
        loopTime %= 140 * order.length;
        if (getYvel() != 0)
                pos = 5;
        else 
            if (Math.abs(getXvel()) < 10)
                pos = 0;
            else
                pos = order[loopTime / 140];
        
        //display the health
        gc.setFill(Color.RED);
        gc.fillRect(getX(), getY() - 15, 30, 10);
        gc.setFill(Color.GREEN);
        gc.fillRect(getX(), getY() - 15, 30.0 * getHealth() / getMaxHealth(), 10);

        if (getXvel() >= 0)
            gc.drawImage(getImage(), pos * 30, 0, 30, getHeight(),
                getX(), getY() + 5, 30, getHeight());
        else
            gc.drawImage(getImage(), pos * 30, 0, 30, getHeight(),
                getX() + 30, getY() + 5, -30, getHeight());
    }
}


