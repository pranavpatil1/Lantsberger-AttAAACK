import java.util.List;
import java.util.ArrayList;
import javafx.scene.image.Image;
/**
 * class EnemyAI controls many enemies
 *
 * @author Pranav Patil
 * @version 05.28.18
 */
public class EnemyAI
{
    // list of enemies to handle
    private List<Enemy> myEnemies;
    private List<Block> myBlocks;
    private Fighter myTarget;
    private static Sprite coll = new Sprite(0, 0, 2, 2, new Image("qBlock.png"));
    private static Sprite coll2 = new Sprite(0, 0, 2, 2, new Image("qBlock.png"));

    /**
     * constructor EnemyAI sets the list of enemies to handle
     */
    public EnemyAI(List<Enemy> enemies, List<Block> blocks, Fighter target)
    {
        myEnemies = enemies;
        myBlocks = blocks;
        myTarget = target;
    }

    /**
     * method setTarget - changes the target that the enemies are all attacking :P
     */
    public void setTarget (Fighter target)
    {
        myTarget = target;
    }
    /**
     * method update
     */
    public void update(int millis)
    {
        // checks if the enemy has space to the left
        boolean hit = false;
        // checks if the enemy has space way over to the right
        boolean hit2 = false;
        // check if the enemy is on the ground
        boolean down = false;
        for (Enemy e : myEnemies)
        {
            hit = false;
            hit2 = false;
            down = false;
            coll.setPosition(e.getX(), e.getY() + e.getHeight() - 1);
            for (Block b : myBlocks)
            {
                if (coll.isCollision(b))
                    down = true;
            }
            if (e.isLeft())
            {
                e.moveLeft();
                if (down)
                {
                    coll.setPosition(e.getX() - 20, e.getY() + e.getHeight() - 1);
                    coll2.setPosition(e.getX() - 170, e.getY() + e.getHeight() - 1);
                    for (Block b : myBlocks)
                    {
                        if (coll.isCollision(b))
                            hit = true;
                        if (coll2.isCollision(b))
                            hit2 = true;
                    }
                    if (!hit && hit2 && Math.random() < 1)
                        e.jump();
                    else
                        if (!hit)
                            e.setLeft(false);
                }
            }
            else
            {
                e.moveRight();
                if (down)
                {
                    coll.setPosition(e.getX() + 20 + e.getWidth(), e.getY() + e.getHeight() - 1);
                    coll2.setPosition(e.getX() + 170 + e.getWidth(), e.getY() + e.getHeight() - 1);
                    for (Block b : myBlocks)
                    {
                        if (coll.isCollision(b))
                            hit = true;
                        if (coll2.isCollision(b))
                            hit2 = true;
                    }
                    if (!hit && hit2 && Math.random() < 0.5)
                        e.jump();
                    else
                        if (!hit)
                            e.setLeft(true);
                }
            }
            if (Math.random() < 0.001)
                e.setLeft(!e.isLeft());
            if (myTarget != null)
                e.attack(myTarget);
        }
    }
}