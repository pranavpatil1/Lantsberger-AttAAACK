import javafx.scene.image.Image;
import javafx.scene.canvas.GraphicsContext;
/**
 * Class QBlock creates a question block
 *
 * @author (JaneWang)
 * @version (06032018)
 */
public class QBlock extends Block
{
    /**
     * Constructor for objects of class QBlock 
     */
    public QBlock(double x, double y)
    {
        super(x, y, 60, 60, new Image("qBlock.png"));
    }

    @Override
    public void draw(GraphicsContext gc, int millis)
    {
       gc.drawImage(new Image("qBlock.png"), getX(), getY());
    }
}
